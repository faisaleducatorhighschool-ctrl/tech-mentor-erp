{pkgs}: {
  deps = [
    pkgs.mariadb
  ];
}
